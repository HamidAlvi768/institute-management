import React, { useState } from 'react';
import { Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import classnames from 'classnames';
import UserPanel from './UserPanel';
import OrderStatus from "./OrderStatus";
import Notifications from "./Notifications";
import SocialSource from "./SocialSource";
import OverView from "./OverView";
import RevenueByLocation from "./RevenueByLocation";
import LatestTransation from "./LatestTransation";
import EnrollmentAnalyticsChart from "./EnrollmentAnalyticsChart";
import EmploymentOutcomesChart from "./EmploymentOutcomesChart";
import InstituteMetricsChart from "./InstituteMetricsChart";
import CombinedProgramsChart from "./CombinedProgramsChart";
import CertificationTrainersChart from "./CertificationTrainersChart";
import ProgramsTradesChart from "./ProgramsTradesChart";
import EnrollmentPassoutChart from "./EnrollmentPassoutChart";
import SectorsAnalytics from "./SectorsAnalytics";
import ProgramsPieChart from './ProgramsPieChart';
import AffiliationBodiesChart from './AffiliationBodiesChart';

import { Row, Container, Col, Card, CardBody, CardTitle } from "reactstrap";

const NavTab = () => {
    const [activeTab, setActiveTab] = useState('1');

    const toggleTab = (tab) => {
        if (activeTab !== tab) setActiveTab(tab);
    };

    return (
        <div className="mb-4">
            <Nav tabs>
                <NavItem>
                    <NavLink style={{ cursor: 'pointer' }}
                        className={classnames({ active: activeTab === '1' })}
                        onClick={() => toggleTab('1')}
                    >
                        All (Institute)
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink style={{ cursor: 'pointer' }}
                        className={classnames({ active: activeTab === '2' })}
                        onClick={() => toggleTab('2')}
                    >
                        Trades
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink style={{ cursor: 'pointer' }}
                        className={classnames({ active: activeTab === '3' })}
                        onClick={() => toggleTab('3')}
                    >
                        Sectors
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink style={{ cursor: 'pointer' }}
                        className={classnames({ active: activeTab === '4' })}
                        onClick={() => toggleTab('4')}
                    >
                        Enrollment
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink style={{ cursor: 'pointer' }}
                        className={classnames({ active: activeTab === '5' })}
                        onClick={() => toggleTab('5')}
                    >
                        Trainers
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink style={{ cursor: 'pointer' }}
                        className={classnames({ active: activeTab === '6' })}
                        onClick={() => toggleTab('6')}
                    >
                        Certification
                    </NavLink>
                </NavItem>
            </Nav>

            <TabContent activeTab={activeTab}>
                {/* Tab 1: All Institute - Keeping the exact layout and ordering from NavTabLayout */}
                <TabPane tabId="1">
                    <Row>
                        <ProgramsPieChart />
                        <ProgramsTradesChart />
                        <CombinedProgramsChart />
                        <EnrollmentPassoutChart />
                        <EnrollmentAnalyticsChart />
                        <CertificationTrainersChart />
                        <EmploymentOutcomesChart />
                        <SectorsAnalytics />
                        <AffiliationBodiesChart />
                    </Row>
                </TabPane>
                
                {/* Tab 2: Trades */}
                <TabPane tabId="2">
                    <Row>
                        <Col xl={6}>
                            <ProgramsTradesChart columnSize={12} />
                        </Col>
                        <Col xl={6}>
                            <CombinedProgramsChart columnSize={12} />
                        </Col>
                    </Row>
                </TabPane>
                
                {/* Tab 3: Sectors */}
                <TabPane tabId="3">
                    <Row>
                        <Col xl={6}>
                            <SectorsAnalytics columnSize={12} />
                        </Col>
                        <Col xl={6}>
                            <Card>
                                <CardBody>
                                    <CardTitle className="mb-4">Programs by Sector</CardTitle>
                                    <ProgramsTradesChart columnSize={12} />
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </TabPane>
                
                {/* Tab 4: Enrollment */}
                <TabPane tabId="4">
                    <Row>
                        <Col xl={6}>
                            <EnrollmentAnalyticsChart columnSize={12} />
                        </Col>
                        <Col xl={6}>
                            <EnrollmentPassoutChart columnSize={12} />
                        </Col>
                    </Row>
                </TabPane>
                
                {/* Tab 5: Trainers */}
                <TabPane tabId="5">
                    <Row>
                        <Col xl={6}>
                            <CertificationTrainersChart columnSize={12} />
                        </Col>
                        <Col xl={6}>
                            <Card>
                                <CardBody>
                                    <CardTitle className="mb-4">Trainer Qualifications</CardTitle>
                                    <EmploymentOutcomesChart columnSize={12} />
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </TabPane>
                
                {/* Tab 6: Certification */}
                <TabPane tabId="6">
                    <Row>
                        <Col xl={6}>
                            <CertificationTrainersChart columnSize={12} />
                        </Col>
                        <Col xl={6}>
                            <EmploymentOutcomesChart columnSize={12} />
                        </Col>
                    </Row>
                </TabPane>
            </TabContent>
        </div>
    );
}

export default NavTab;